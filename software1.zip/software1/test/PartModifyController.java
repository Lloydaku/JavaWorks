/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import App.View.*;
import App.Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

/**
 *
 * @author Klinn
 */
public class PartModifyController {
    
    @FXML private TextField partIdTextField;
    @FXML private TextField partNameTextField;
    @FXML private TextField partInvTextField;
    @FXML private TextField partPriceCostTextField;
    @FXML private TextField partMaxTextField;
    @FXML private TextField partMinTextField;
    @FXML private TextField partCompanyNameTextField;
    
    
    
    @FXML private Label CompanyLabel;
    @FXML private ToggleGroup partToggleGroup;
    
    private Stage modifyStage;
    private Part part;
    private boolean saveClicked = false;
    
    @FXML private void initialize(){
        
    }
    
    public void setModifyStage(Stage modifyStage){
        this.modifyStage = modifyStage;
    }
    
    public void setPart(Part part) {
        this.part = part;
        
        partIdTextField.setText(Integer.toString(part.getPartId()));
        partNameTextField.setText(part.getPartName());
        partInvTextField.setText(Integer.toString(part.getPartsInvLevel()));
        partPriceCostTextField.setText(Double.toString(part.getPartPriceCostPerUnit()));
    }
    
    public boolean isSaveClicked() {
        return saveClicked;
    }
  
    private boolean inHousePart;
    
    public void partToggleGroup (ActionEvent event) {
       if (partToggleGroup.getSelectedToggle().toString().contains("In-House")) {
           
            inHousePart = true;
            
            partIdTextField.setEditable(false);
            partNameTextField.setEditable(true);
            partInvTextField.setEditable(true);
            partPriceCostTextField.setEditable(true);
            CompanyLabel.setText("Machine Id");
        } else {
          
            partIdTextField.setEditable(false);
            partNameTextField.setEditable(true);
            partInvTextField.setEditable(true);
            partPriceCostTextField.setEditable(true);
            CompanyLabel.setText("Company Name");
       }
    }
    
    @FXML
    private void handleSave() {
        if (isInputValid()) {
            part.setPartId(Integer.parseInt(partIdTextField.getText()));
            part.setPartName(partNameTextField.getText());
            part.setPartsInvLevel(Integer.parseInt(partInvTextField.getText()));
            part.setPartPriceCostPerUnit(Double.parseDouble(partPriceCostTextField.getText()));
            
            saveClicked = true;
            modifyStage.close();
        }
    }
    
    @FXML
    private void handleCancel() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Cancel...");
        alert.setHeaderText("Canceling...");
        alert.setContentText("Would you like to cancel modifying part?");        
        alert.showAndWait();
        
        modifyStage.close();
    }
    
    private boolean isInputValid(){
        String errorMessage ="";
        
        if (partIdTextField.getText() == null || partIdTextField.getText().length() == 0) {
            errorMessage += "No Valid part Id! \n";
        }
        if (partNameTextField.getText() == null || partNameTextField.getText().length() == 0) {
            errorMessage += "No Valid part Name! \n";
        }
        if (partInvTextField.getText() == null || partInvTextField.getText().length() == 0) {
            errorMessage += "No Valid part Inventory! \n";
        }
        if (partPriceCostTextField.getText() == null || partPriceCostTextField.getText().length() == 0) {
            errorMessage += "No Valid part Price! \n";
        }
        
        if (errorMessage.length() == 0) {
            return true;
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(modifyStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
        
    }
    
    
    
            
            
}
