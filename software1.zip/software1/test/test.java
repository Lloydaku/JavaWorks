/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Klinn
 */
public class test {
    
    public static void main(String[] args) {
        
    }
    
    int result = 0;
    
    private test(){
    for(int i = 0; i<5; i++) {
    if (i == 3){
        result += 10;
    } else {
        result +=i;
    }
        System.out.println(result);
    }
    
}
}
