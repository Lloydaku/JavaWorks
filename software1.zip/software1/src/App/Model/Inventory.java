/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Model;

import App.View.MainController;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 *
 * @author Klinn
 */
public class Inventory {
    
    //private static ArrayList<Product> allProducts = new ArrayList();
    //private static ArrayList<Part> allParts = new ArrayList();
    
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    
    //Temp List for Search results.
    private static ObservableList<Part> findParts = FXCollections.observableArrayList();
    private static ObservableList<Product> findProd = FXCollections.observableArrayList();
    
    public static ObservableList<Part> getAllParts() {
        return allParts;
        
    }
    
    public void addPart(Part partName) {
        allParts.add(partName);
    }
    
    public void addInvLvl(Part partsInvLevel){
        allParts.add(partsInvLevel);
    }
    public void addPrice(Part partPriceCostPerUnit) {
        allParts.add(partPriceCostPerUnit);
    }
    
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }
    
   public void addProduct(Product inProduct) {
       allProducts.add(inProduct);  
    }
   
   
    
    public boolean removeProduct(int rProductID) {
        try {
            allProducts.remove(rProductID);
            return true;
        } catch(Exception ex) {
            return false;
        }
    }
    
    public Product lookupProduct(int productID) {
       try {
           return allProducts.get(productID);
       } catch(Exception ex) {
           return null;
       }
    }
    
    public Part lookupPart (String name) {
        Part partfound = null;
        for (Part part : allParts) {
                if(name.toLowerCase().equals(part.getPartName().toLowerCase())) {
                    partfound = part;
                    break;
                }
        }
        return partfound;
    }
    
    public ObservableList<Part> searchforStringPart (String str) {
        ObservableList<Part> partfound = FXCollections.observableArrayList();
        
        String name = null;
        String company = null;
        String machineId = null;
        String price = null; // need to impletment.
        
        System.out.println("All Parts" + allParts);
        System.out.println("Part Data" + MainController.partData);
        
        for (Part part : MainController.partData) {
                        name = part.getPartName();
			machineId = part instanceof InhousePart ? String.valueOf(((InhousePart)part).getMachineId()) : "";
			company = part instanceof OutsourcedPart ? ((OutsourcedPart)part).getCompanyName() : "";
                        
			
                            System.out.println(name.toLowerCase());
                            System.out.println(machineId.toLowerCase());
                            System.out.println(company.toLowerCase());
                            System.out.println("String we are comparing " + str.toLowerCase());
                            
                        if (name.toLowerCase().contains(str.toLowerCase()) ||
                            machineId.toLowerCase().contains(str.toLowerCase()) ||
                            company.toLowerCase().contains(str.toLowerCase())) {
                            
                            partfound.add(part); 
                            
                            
                            System.out.println("Yes is added it " + partfound);
                        }
        }
        return partfound;
    }
    
    // Search for Prod
    public ObservableList<Product> searchforStringProd (String str) {
        ObservableList<Product> productFound = FXCollections.observableArrayList();
        
        String name = null;
        
        System.out.println("All Product" + allProducts);
        System.out.println("Prod Data" + MainController.prodData);
            
            for(Product prod : MainController.prodData) {
                name = prod.getProdName();
                
                System.out.println(name.toLowerCase());
                
                if (name.toLowerCase().contains(str.toLowerCase())) {
                    productFound.add(prod);
                    
                    System.out.println("Yes part is found" + productFound);
                }
            }
        return productFound;
    }
    
    
    

    
    public void updateProduct(int updateProduct) {
        
    }
    
}
