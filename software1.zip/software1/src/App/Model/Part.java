/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Model;

import App.Model.InhousePart;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


/**
 *
 * @author Klinn
 */
public abstract class Part {
    private final IntegerProperty partId;
    private final StringProperty partName;
    private final IntegerProperty partsInvLevel;
    private final DoubleProperty partPriceCostPerUnit;
    private final IntegerProperty min;
    private final IntegerProperty max;
    
    
    public static int numberPartId = 0;
    

    

    /**
     * Default constructor.
     */
    public Part() {
      this(null,0,0.0);
    }
    
    /**
     * Constructor with some initial data.
     * 
     * 
     */
    public Part(String partName, int partsInvLevel, double partPriceCostPerUnit) { 
        this.partId = new SimpleIntegerProperty(numberPartId++);
        this.partName = new SimpleStringProperty(partName);
        this.partsInvLevel = new SimpleIntegerProperty(partsInvLevel);
        this.partPriceCostPerUnit = new SimpleDoubleProperty(partPriceCostPerUnit);
        this.min = new SimpleIntegerProperty(0);
        this.max = new SimpleIntegerProperty(0);
    }

    public int getPartId() {
        return partId.get();
    }

    public void setPartId(int partId) {
        this.partId.set(partId);
    }

    public IntegerProperty partIdProperty() {
        return partId;
    }

    public String getPartName() {
        return partName.get();
    }

    public void setPartName(String partName) {
        this.partName.set(partName);
    }

    public StringProperty partNameProperty() {
        return partName;
    }

    public int getPartsInvLevel() {
        return partsInvLevel.get();
    }

    public void setPartsInvLevel(int partsInvLevel) {
        this.partsInvLevel.set(partsInvLevel);
    }

    public IntegerProperty partInvProperty() {
        return partsInvLevel;
    }

    public double getPartPriceCostPerUnit() {
        return partPriceCostPerUnit.get();
    }

    public void setPartPriceCostPerUnit(double partPriceCostPerUnit) {
        this.partPriceCostPerUnit.set(partPriceCostPerUnit);
    }

    public DoubleProperty partPriceCostPerUnitProperty() {
        return partPriceCostPerUnit;
    }
    
     public int getMax() {
        return max.get();
    }

    public void setMax(int max) {
        this.max.set(max);
    }

    public IntegerProperty maxProperty() {
        return max;
    }
    
     public int getMin() {
        return min.get();
    }

    public void setMin(int min) {
        this.min.set(min);
    }

    public IntegerProperty minProperty() {
        return min;
    }
}

