/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 *
 * @author Klinn
 */
public class OutsourcedPart extends Part{
    
    
    public OutsourcedPart(String partName, int partsInvLevel, double partPriceCostPerUnit, String companyName){
        super(partName, partsInvLevel, partPriceCostPerUnit); 
        this.companyName = companyName;
    }
    
    private static String companyName;
    
    public static String getCompanyName() {
        return companyName;
    }
    
    public void setCompanyName(String inCompanyName){
        this.companyName = inCompanyName;
    }
    
    
}
