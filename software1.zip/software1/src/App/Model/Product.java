/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Model;

import java.util.ArrayList;
import java.util.List;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Klinn
 */
public class Product {
    
    public ArrayList<Part> parts;
    
    private IntegerProperty productId;
    private StringProperty prodName;
    private DoubleProperty prodPrice;
    private IntegerProperty instock;
    private IntegerProperty min;
    private IntegerProperty max;
    private static int numberProdId = 0;
    
    
    
    public Product() {
        this(null,0,0.0);
    }
    
    public Product(String prodName, int instock, double price) {
        this.productId = new SimpleIntegerProperty(numberProdId++);
        this.prodName = new SimpleStringProperty(prodName);
        this.instock = new SimpleIntegerProperty(instock);
        this.prodPrice = new SimpleDoubleProperty(price);
        this.min = new SimpleIntegerProperty(0);
        this.max = new SimpleIntegerProperty(0);
    }

    public void setParts(ArrayList<Part> parts) {
        this.parts = parts;
    }
    
    public ArrayList getParts() {
        return parts;
    }

    public int getProdId() {
        return productId.get();
    }
    
    public void setProductID() {
        this.productId.set(numberProdId++);
    }
    
    public void setProdId(int productId) {
        this.productId.set(productId);
    }
    
    public IntegerProperty productIdProperty() {
        return productId;
    }
    
    public String getProdName() {
        return prodName.get();
    }
    
    public void setProdName(String prodName) {
        this.prodName.set(prodName);
    }
    
    public StringProperty prodNameProperty() {
        return prodName;
    }
    
    public int getInstock() {
        return instock.get();
    }
    
    public void setInstock(int instock) {
        this.instock.set(instock);
    }
    
    public IntegerProperty prodInstockProperty() {
        return instock;
    }
    
    public double getProdPrice() {
        return prodPrice.get();
    }
    
    public void setProdPrice(double prodPrice) {
        this.prodPrice.set(prodPrice);
    }
    
    public DoubleProperty prodPriceProperty() {
        return prodPrice;
    }
    
     public int getMax() {
        return max.get();
    }

    public void setMax(int max) {
        this.max.set(max);
    }

    public IntegerProperty maxProperty() {
        return max;
    }
    
     public int getMin() {
        return min.get();
    }

    public void setMin(int min) {
        this.min.set(min);
    }

    public IntegerProperty minProperty() {
        return min;
    }
    
    
   
    
    
    
    
    
}
