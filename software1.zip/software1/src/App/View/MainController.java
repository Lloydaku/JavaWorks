/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.View;


import App.MainApp;
import App.Model.InhousePart;
import App.Model.Inventory;
import App.Model.OutsourcedPart;
import App.Model.Part;
import App.Model.Product;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 *
 * @author Klinn
 */
public class MainController {
    
    //Part Table view and Column
    @FXML private TableView <Part> partTable;
    private Inventory inventory = new Inventory();
   
    
    @FXML private TableColumn <Part, Integer> partIdColumn;
    @FXML private TableColumn <Part, String> partNameColumn;
    @FXML private TableColumn <Part, Integer> partInvColumn;
    @FXML private TableColumn <Part, Double> priceCostColumn;
    
    //Product Table view and Columns
    @FXML private TableView<Product> productTable;
    
    @FXML private TableColumn <Product, Integer> prodIdColumn;
    @FXML private TableColumn <Product, String> prodNameColumn;
    @FXML private TableColumn <Product, Integer> prodInstockColumn;
    @FXML private TableColumn <Product, Double> prodPriceColumn;
            
    @FXML private TextField searchPartText;
    @FXML private TextField searchProdText;
    
    @FXML private Button modifyPart;
    @FXML private Button deletePart;
    @FXML private Button modifyProd;
    @FXML private Button deleteProd;
    
    public static Part selectedPart;
    public static Product selectedProd;
    
    public static ObservableList<Part> partData = FXCollections.observableArrayList(Inventory.getAllParts());
    public static ObservableList<Product> prodData = FXCollections.observableArrayList(Inventory.getAllProducts());
    
  
    
    private MainApp mainApp;
    
    public MainController() {
    }
    
    @FXML
    private void initialize() {
        
        partData.add(new InhousePart("In House Part", 2, 1.25, 1234));
        partData.add(new OutsourcedPart("Outsourced Part",  2, 1.25, "Company"));
        
        partIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().partIdProperty().asObject());
        partNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().partNameProperty());
        partInvColumn.setCellValueFactory(
                cellData -> cellData.getValue().partInvProperty().asObject());
        priceCostColumn.setCellValueFactory
        (cellData -> cellData.getValue().partPriceCostPerUnitProperty().asObject());
        
        //showPartDetails(null);
        partTable.setItems(partData);
        
        //Test Prod Data
        /*
        prodData.add(new Product("Car", 2,1.25));
        prodData.add(new Product("Laptop", 2,1.25));
        prodData.add(new Product("Computer", 2,1.25));
        */
        
        prodIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().productIdProperty().asObject());
        prodNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().prodNameProperty());
        prodInstockColumn.setCellValueFactory(
                cellData -> cellData.getValue().prodInstockProperty().asObject());
        prodPriceColumn.setCellValueFactory(
                cellData -> cellData.getValue().prodPriceProperty().asObject());
        
        productTable.setItems(prodData);
        
        
        // Button State
        changeButtonState(partTable, true);
        changeButtonState(productTable, true);
        
        //listener.  
        partTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) ->
            changeButtonState(partTable, newSel == null));
        productTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel)-> 
            changeButtonState(productTable, newSel == null));
        
        //partTable.getSelectionModel().selectedItemProperty().addListener(
                //(observable, oldValue, newValue) -> showPartDetails(newValue));
                
        //Listener for part search field.        
        searchPartText.textProperty().addListener((obs, oldText, newText) -> {
            if (newText == null || newText.isEmpty()) {
                partTable.setItems(inventory.getAllParts());
            }
        });
        
        searchProdText.textProperty().addListener((obs, oldText, newText)-> {
            if (newText == null || newText.isEmpty()) {
                productTable.setItems(inventory.getAllProducts());
            }
        }); 
    }
 
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        
        
        partTable.setItems(partData);
        productTable.setItems(prodData);
    }
    
    
    private void showPartDetails (Part part) {
    }
    private void showProdDetails (Product prod) {
        
    }
    
    private boolean delete;
    
    @FXML
    private void handleDeletePart() {
        try{
        Part selectedItem = partTable.getSelectionModel().getSelectedItem();
        if (delete = true) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete?");
            alert.setHeaderText("Would you like to Delete the selected Part: "  + selectedItem.getPartName() + " ?");
            alert.initOwner(mainApp.getPrimaryStage());
            
           Optional<ButtonType> result = alert.showAndWait();
           if (result.get() == ButtonType.OK) {
           partTable.getItems().remove(selectedItem);
           }
        }
        
        } catch (Exception e) {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a Part in the table to delete.");

            alert.showAndWait();
        }
         
    }
    
    @FXML 
    private void handleDeleteProd(){
        try{
        Product selectedItem = productTable.getSelectionModel().getSelectedItem();
            System.out.println(selectedItem.parts);
        if (selectedItem.parts.size()> 0 ) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning!");
            alert.setHeaderText("Prodcut Contains a Part");
            alert.setContentText("Product cannot not be deleted if it contains a part.");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                //productTable.getItems().remove(selectedItem);
            }
        }   
        
        } catch (Exception e) {
             // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("Warning!");
            alert.setHeaderText("Prodcut Contains a Part");
            alert.setContentText("Product cannot not be deleted if it contains a part.");

            alert.showAndWait();
        } 
    }
    
   
    
   
    
    @FXML
    private void handleNewPart() {
        //Part tempPart = new Part();
        boolean saveClicked = mainApp.showAddPartDialog();
        if (saveClicked) {
            //mainApp.getPartData().add();
        }
    }
    
     
    @FXML
    private void handleNewProd(){
        boolean saveClicked = mainApp.showAddProductDialog();
        if (saveClicked) {
            
        }
    }

    @FXML
    private void handleEditPart() {
        selectedPart = partTable.getSelectionModel().getSelectedItem();
        if (selectedPart != null) {
            boolean saveClicked = mainApp.showPartEditDialog(selectedPart);
            if (saveClicked) {
                showPartDetails(selectedPart);
            }

        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Part Selected");
            alert.setContentText("Please select a Part in the table.");

            alert.showAndWait();
                    
        }
    }
      //Needs work.  Keep adding a new part.  
    @FXML
    private void handleEditProd(){
        selectedProd = productTable.getSelectionModel().getSelectedItem();
        if (selectedProd != null) {
            boolean saveClicked = mainApp.showEditProductDialog(selectedProd);
            if (saveClicked) {
                showProdDetails(selectedProd);
            }

        } else {
            // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a Product in the table.");

            alert.showAndWait()
                    .filter(response -> response == ButtonType.OK).ifPresent(reponse -> MainApp.primaryStage.close());
        }
    }
    
        
    @FXML
    private void handleSearchPart() {
        String searchText = searchPartText.getText();
        if (searchText == null || searchText.isEmpty()) {
            partTable.setItems(inventory.getAllParts());
        }
        System.out.println(inventory);
        ObservableList<Part> partfound = inventory.searchforStringPart(searchText);
        partTable.setItems(partfound);
        
        System.out.println(partfound);
    }
    
    @FXML
    private void searchForProduct() {
        String searchText = searchProdText.getText();
        if (searchText == null || searchText.isEmpty()) {
            productTable.setItems(inventory.getAllProducts());
        }
        System.out.println(inventory);
        ObservableList<Product> productFound = inventory.searchforStringProd(searchText);
        productTable.setItems(productFound);
        
        System.out.println(productFound);
    }
    
    
    
    private void changeButtonState(TableView<?> table, boolean state) {
        if (table.equals(partTable)) {
            modifyPart.setDisable(state);
            deletePart.setDisable(state);
        } else if (table.equals(productTable)) {
            modifyProd.setDisable(state);
            deleteProd.setDisable(state);
        }
    }
    
            
    @FXML
    public void exitButton() {
         Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit?");
        alert.setHeaderText("Are you sure you wait to quit?");
        alert.setContentText("Press OK to Exit the program");        
        alert.showAndWait()
                .filter(response -> response == ButtonType.OK).ifPresent(reponse -> MainApp.primaryStage.close());
        
    }
    
    /*@FXML  Not needed.
    public void exitButton(ActionEvent event) {
        final Node source = (Node) event.getSource();
        final Stage stageExt = (Stage) source.getScene().getWindow();
        stageExt.close();
    }*/

    

}
