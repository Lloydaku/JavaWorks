/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Controller;

import App.Model.Inventory;
import App.Model.Part;
import App.Model.Product;
import App.View.MainController;
import static App.View.MainController.partData;
import static App.View.MainController.selectedProd;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Klinn
 */
public class ProductModifyController {
    
    @FXML private TextField prodIdTextfield;
    @FXML private TextField prodNameTextField;
    @FXML private TextField prodInvTextField;
    @FXML private TextField prodPriceTextField;
    @FXML private TextField prodMaxTextField;
    @FXML private TextField prodMinTextField;
    
    @FXML private TableView UpperTable;
    @FXML private TableColumn <Part, Integer>upperPardIdColumn;
    @FXML private TableColumn <Part, String>upperPartNameColumn;
    @FXML private TableColumn <Part, Integer>upperInvLevelColumn;
    @FXML private TableColumn <Part, Double>upperPriceColumn;
    
    @FXML private TableView LowerTable;
    @FXML private TableColumn <Part, Integer>lowerPardIdColumn;
    @FXML private TableColumn <Part, String>lowerNameColumn;
    @FXML private TableColumn <Part, Integer>lowerInvLevelColumn;
    @FXML private TableColumn <Part, Double>lowerPriceColumn;
    
    
    //private static ArrayList<Part> parts = new ArrayList<>();
    ArrayList<Part> parts = MainController.selectedProd.getParts();
    public ObservableList<Part> partList = FXCollections.observableArrayList(parts);
    
    
    private Stage modifyProdStage;
    private Product product;
    private boolean saveClicked = false;
    
    @FXML
    private void initialize(){
        
        upperPardIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().partIdProperty().asObject());
        upperPartNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().partNameProperty()); 
        upperInvLevelColumn.setCellValueFactory(
                cellData -> cellData.getValue().partInvProperty().asObject());
        upperPriceColumn.setCellValueFactory(
                cellData -> cellData.getValue().partPriceCostPerUnitProperty().asObject());
        
        UpperTable.setItems(partData);
        
         lowerPardIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().partIdProperty().asObject());
        lowerNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().partNameProperty()); 
        lowerInvLevelColumn.setCellValueFactory(
                cellData -> cellData.getValue().partInvProperty().asObject());
        lowerPriceColumn.setCellValueFactory(
                cellData -> cellData.getValue().partPriceCostPerUnitProperty().asObject());
        
        LowerTable.setItems(partList);
        
    }
    
    public void setModifyProdStage(Stage modifyProdStage) {
        this.modifyProdStage = modifyProdStage;
    }
    
    public void setProd(Product selectedProd) {
        this.product = selectedProd;
        
        
        
        prodIdTextfield.setText(Integer.toString(product.getProdId()));
        prodNameTextField.setText(product.getProdName());
        prodInvTextField.setText(Integer.toString(product.getInstock()));
        prodPriceTextField.setText(Double.toString(product.getProdPrice()));
        prodMaxTextField.setText(Integer.toString(product.getMax()));
        prodMinTextField.setText(Integer.toString(product.getMin()));
    }
    
    public boolean SaveClicked(){
        return saveClicked;
    }
    //Handling adding parts to created a prod in lower table
    @FXML
    private void handleAddPartToProd(){
         partList.add((Part)(UpperTable.getSelectionModel().getSelectedItem()));
         
    }
    
    //Hanlde saved Product
    @FXML 
    private void handleSaveProdbtn() {
        
        
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.initOwner(modifyProdStage);
        alert.setTitle("Product has not been saved");
        
        
        String name = prodNameTextField.getText();
        String stock = prodInvTextField.getText();
        double price = Double.parseDouble(prodPriceTextField.getText());
        String price2 = prodPriceTextField.getText();
        String max = prodMaxTextField.getText();
        String min = prodMinTextField.getText();
        try {
           
        if (name.isEmpty() || stock.isEmpty() || price2.isEmpty()) {
            throw new IllegalArgumentException("All Text Field Must be Fill In.");
        }
        if (partList.isEmpty()) {
            throw new IllegalArgumentException ("Product Must Contain At Least One Part!");
        }
        double partPrice = getPriceOfPart();
        
        if (partPrice > price) {
            throw new IllegalArgumentException ("Price cannot be less than the Total");
        }
        
        
            Product p = new Product(
                
            prodNameTextField.getText(),
            Integer.parseInt(prodInvTextField.getText()),
            Double.parseDouble(prodPriceTextField.getText())
            
        );
        p.setMax(Integer.parseInt(prodMaxTextField.getText()));
        p.setMin(Integer.parseInt(prodMinTextField.getText()));
        ArrayList<Part> temp = new ArrayList<>(LowerTable.getItems());
        p.setParts(temp);
        System.out.println(p.parts);
        
        
        
             MainController.prodData.add(p);
             modifyProdStage.close();
    }catch (IllegalArgumentException e) {
        alert.setContentText(e.getMessage());;
	alert.showAndWait();
	return;
    }
        
    }
        
     private double getPriceOfPart() {
        double partPrice = 0;
        
        ObservableList<Part> partInTable = LowerTable.getItems();
        
        if (partInTable == null || partInTable.isEmpty()) {
            return partPrice;
        }
        for (Part part : partInTable) {
            partPrice += part.getPartPriceCostPerUnit();
        }
        return partPrice;
    }
    private boolean delete;
    
    // Handled delete product
    @FXML
    private void handleDeleteProdBtn() {
       try{
        int selectedIndex = LowerTable.getSelectionModel().getSelectedIndex();
           Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
           alert.setTitle("Delete?");
           alert.setHeaderText("Would you like to Delete the selected Part ?");
           
            
           Optional<ButtonType> result = alert.showAndWait();
           if (result.get() == ButtonType.OK) {  
               LowerTable.getItems().remove(selectedIndex);
           
        }
      
        } catch (Exception e) {
             // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("No Selection");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a Part in the table to delete.");

            alert.showAndWait();
        }
    
    }
    //Handles product Search
    @FXML
    private void handleSearchProdbtn() {
       
    }
    //Clocked out App Prodct Window
    @FXML
    private void prodCancelBtn() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Cancel...");
        alert.setHeaderText("Canceling...");
        alert.setContentText("Would you like to cancel now?");        
        alert.showAndWait()
                .filter(response -> response == ButtonType.OK).ifPresent(reponse -> modifyProdStage.close());
      
    }
    
    
}
