/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package App.Controller;

import App.MainApp;
import App.Model.Inventory;
import App.Model.Part;
import App.Model.Product;
import App.View.MainController;
import static App.View.MainController.partData;
import java.util.ArrayList;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author Klinn
 */
public class ProductAddController {
    
    private Inventory inventory = new Inventory();
    
    @FXML private TextField prodIdTextfield;
    @FXML private TextField prodNameTextField;
    @FXML private TextField prodInvTextField;
    @FXML private TextField prodPriceTextField;
    @FXML private TextField prodMaxTextField;
    @FXML private TextField prodMinTextField;
    
    @FXML private TableView UpperTable;
    @FXML private TableColumn <Part, Integer>upperPardIdColumn;
    @FXML private TableColumn <Part, String>upperPartNameColumn;
    @FXML private TableColumn <Part, Integer>upperInvLevelColumn;
    @FXML private TableColumn <Part, Double>upperPriceColumn;
    
    @FXML private TableView <Part> LowerTable;
    @FXML private TableColumn <Part, Integer>lowerPardIdColumn;
    @FXML private TableColumn <Part, String>lowerNameColumn;
    @FXML private TableColumn <Part, Integer>lowerInvLevelColumn;
    @FXML private TableColumn <Part, Double>lowerPriceColumn;
    
    @FXML private Button addBtn;
    @FXML private Button deleteBtn;
    @FXML private TextField SearchTextField;
    
    private static ArrayList<Part> parts = new ArrayList<>();
    public  ObservableList<Part> partList = FXCollections.observableArrayList();
    
    
    private Stage addProdStage;
    private boolean saveClicked = false;
    
    @FXML
    private void initialize(){
        
        upperPardIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().partIdProperty().asObject());
        upperPartNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().partNameProperty()); 
        upperInvLevelColumn.setCellValueFactory(
                cellData -> cellData.getValue().partInvProperty().asObject());
        upperPriceColumn.setCellValueFactory(
                cellData -> cellData.getValue().partPriceCostPerUnitProperty().asObject());
        
        UpperTable.setItems(partData);
        
        lowerPardIdColumn.setCellValueFactory(
                cellData -> cellData.getValue().partIdProperty().asObject());
        lowerNameColumn.setCellValueFactory(
                cellData -> cellData.getValue().partNameProperty()); 
        lowerInvLevelColumn.setCellValueFactory(
                cellData -> cellData.getValue().partInvProperty().asObject());
        lowerPriceColumn.setCellValueFactory(
                cellData -> cellData.getValue().partPriceCostPerUnitProperty().asObject());
        
        LowerTable.setItems(partList);
        
        SearchTextField.textProperty().addListener((obs, oldText, newText) -> {
           if (newText == null || newText.isEmpty()) {
               UpperTable.setItems(inventory.getAllParts());
           } 
        });
            
        
        addBtn.setDisable(true);
        deleteBtn.setDisable(true);
        
        UpperTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> 
				addBtn.setDisable(newSel == null));
		LowerTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> 
				deleteBtn.setDisable(newSel == null));
        
    }
    
    public void setAddProdStage(Stage addProdStage) {
        this.addProdStage = addProdStage;
    }
    
    public boolean isSaveClicked(){
        return saveClicked;
    }
    //Handling adding parts to created a prod in lower table
    @FXML
    private void handleAddPartToProd(){
         partList.add((Part)(UpperTable.getSelectionModel().getSelectedItem()));
         
    }
    
    private boolean invCheck() {
        int inv = Integer.parseInt(prodInvTextField.getText());
        int max = Integer.parseInt(prodMaxTextField.getText());
        int min = Integer.parseInt(prodMinTextField.getText());
        
        if ((max >= inv) && (max >= min) && (min <= inv))
            return true;
        else
            return false;
    }
    
    //Hanlde saved Product
    @FXML 
    private void handleSaveProdbtn() { 
        
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.initOwner(addProdStage);
        alert.setTitle("Product Not Saved!");
        alert.setContentText("Would you like to cancel now?");   
        
        String name = prodNameTextField.getText();
        String stock = prodInvTextField.getText();
       
        String price2 = prodPriceTextField.getText();
        String max = prodMaxTextField.getText();
        String min = prodMinTextField.getText();
        
        try {
            
       
           
        if (name.isEmpty() || stock.isEmpty() || price2.isEmpty() || max.isEmpty() || min.isEmpty()) {
            throw new IllegalArgumentException("All Text Field Must be Fill In.");
        }
        if (partList.isEmpty()) {
            throw new IllegalArgumentException ("Product Must Contain At Least One Part!");
        }
        double partPrice = getPriceOfPart();
        double price = Double.parseDouble(prodPriceTextField.getText());
         
        if (partPrice > price) {
          throw new IllegalArgumentException ("Price cannot be less than the Total");
        }
         if (!invCheck()) {
            throw new Exception("Inventory Must be between Min and Max amounts.");
        }
        Product p = new Product(
                
            prodNameTextField.getText(),
            Integer.parseInt(prodInvTextField.getText()),
            Double.parseDouble(prodPriceTextField.getText())
            
        );
        p.setMax(Integer.parseInt(prodMaxTextField.getText()));
        p.setMin(Integer.parseInt(prodMinTextField.getText()));
        ArrayList<Part> temp = new ArrayList<>(LowerTable.getItems());
        p.setParts(temp);
        System.out.println(p.parts);
        
        
             MainController.prodData.add(p);
             addProdStage.close();
    }catch (IllegalArgumentException e) {
        
        alert.setContentText(e.getMessage());
	alert.showAndWait();
	return;
    }catch (Exception w) {
        alert = new Alert (Alert.AlertType.WARNING); 
        alert.setTitle("Warning Dialog");
        alert.setHeaderText("Warning!");
        alert.setContentText(w.getMessage());
        
        alert.showAndWait();
    }
        
    }  
    
    private double getPriceOfPart() {
        double partPrice = 0;
        
        ObservableList<Part> partInTable = LowerTable.getItems();
        
        if (partInTable == null || partInTable.isEmpty()) {
            return partPrice;
        }
        for (Part part : partInTable) {
            partPrice += part.getPartPriceCostPerUnit();
        }
        return partPrice;
    }
    
    
    boolean delete;
   
    // Handled delete product
    @FXML
    private void handleDeleteProdBtn() {  
       try{
      
        Part selecteditem = LowerTable.getSelectionModel().getSelectedItem();
        if (delete = true) {
           Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
           alert.setTitle("Delete?");
           alert.setHeaderText("Would you like to Delete the selected Part ?");
            
           Optional<ButtonType> result = alert.showAndWait();
           if (result.get() == ButtonType.OK) { 
               LowerTable.getItems().remove(selecteditem);
           }
        }
      
        } catch (Exception e) {
             // Nothing selected.
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("No Selection");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a Part in the table to delete.");

            alert.showAndWait();
        }
    }
    //Handles product Search
    @FXML
    private void handleSearchProdbtn() { 
        String searchText = SearchTextField.getText();
        if (searchText == null || searchText.isEmpty()) {
            UpperTable.setItems(inventory.getAllParts());
        }
        System.out.println(inventory);
        ObservableList<Part> partfound = inventory.searchforStringPart(searchText);
        UpperTable.setItems(partfound);
        
        System.out.println(partfound);
    }
    
    private boolean isInputvalid() {
        String errorMessage = "";
        
        if (prodNameTextField.getText() == null || prodNameTextField.getText().length() == 0) {
            errorMessage += "No valid Product Name! \n";
        }
        if (errorMessage.length() == 0) {
            return true;
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.initOwner(addProdStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);

            alert.showAndWait()
                    .filter(response -> response == ButtonType.CANCEL).ifPresent(reponse -> addProdStage.close());
                  

            return false;
        }
    }
    
    //Clocked out App Prodct Window
    @FXML
    private void prodCancelBtn() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Cancel...");
        alert.setHeaderText("Canceling...");
        alert.setContentText("Would you like to cancel now?");        
        alert.showAndWait()
                .filter(response -> response == ButtonType.OK).ifPresent(reponse -> addProdStage.close());
        
    }
    
    
}
