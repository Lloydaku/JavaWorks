package App;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import App.Model.InhousePart;
import App.Model.Inventory;
import App.Model.OutsourcedPart;
import App.Model.Part;
import App.Model.Product;
import App.Controller.PartModifyController;
import App.View.MainController;
import App.Controller.PartAddController;
import App.Controller.ProductAddController;
import App.Controller.ProductModifyController;
import java.io.IOException;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 *
 * @author Klinn
 */
public class MainApp extends Application {
    public static Stage primaryStage;
    private AnchorPane rootLayout;
    
    // Test Data 
    public MainApp() {
        
    }
    
    /*
    public ObservableList<Part> getPartData() {
        return partData;
    }
    */
    
    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Inventory Managemnet System");
        
       
        
        showMainView();
        
    }
   
     public void showMainView() {
        try {
            // Load part overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/App/View/MainView.fxml"));
            rootLayout = (AnchorPane) loader.load();
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();

            
            //Give controller acces to MainApp
            MainController controller = loader.getController();
            controller.setMainApp(this);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
     
     public boolean showPartEditDialog(Part selectedPart) {
    try {
        // Load the fxml file and create a new stage for the modify part.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainApp.class.getResource("/App/View/modifyPart.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Create the modify Stage.
        Stage modifyStage = new Stage();
        modifyStage.setTitle("Edit Part");
        modifyStage.initModality(Modality.WINDOW_MODAL);
        modifyStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        modifyStage.setScene(scene);

        // Set the part into the controller.
        PartModifyController controller = loader.getController();
        controller.setModifyStage(modifyStage);
        controller.setPart(selectedPart);

        // Show the modify dialog and wait until the user closes it
        modifyStage.showAndWait();

        return controller.isSaveClicked();
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
}
     
    public boolean showAddPartDialog() {
    try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainApp.class.getResource("/App/View/addPart.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage addPartStage = new Stage();
        addPartStage.setTitle("Add Part");
        addPartStage.initModality(Modality.WINDOW_MODAL);
        addPartStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        addPartStage.setScene(scene);

        // Set the part into the controller.
        PartAddController controller = loader.getController();
        controller.setAddPartStage(addPartStage);
        //controller.setPart(part);

        // Show the dialog and wait until the user closes it
        addPartStage.showAndWait();

        return controller.isSaveClicked();
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
}
    
    
    public boolean showAddProductDialog() {
    try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainApp.class.getResource("/App/View/addProduct.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage addProdStage = new Stage();
        addProdStage.setTitle("Add Part");
        addProdStage.initModality(Modality.WINDOW_MODAL);
        addProdStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        addProdStage.setScene(scene);

        
        ProductAddController controller = loader.getController();
        controller.setAddProdStage(addProdStage);
        

        // Show the dialog and wait until the user closes it
        addProdStage.showAndWait();

        return controller.isSaveClicked();
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
}
    public boolean showEditProductDialog(Product selectedProd) {
    try {
        // Load the fxml file and create a new stage for the popup dialog.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainApp.class.getResource("/App/View/modifyProduct.fxml"));
        AnchorPane page = (AnchorPane) loader.load();

        // Create the dialog Stage.
        Stage modifyProdStage = new Stage();
        modifyProdStage.setTitle("Modify Prodcut");
        modifyProdStage.initModality(Modality.WINDOW_MODAL);
        modifyProdStage.initOwner(primaryStage);
        Scene scene = new Scene(page);
        modifyProdStage.setScene(scene);
        
        
        ProductModifyController controller = loader.getController();
        controller.setModifyProdStage(modifyProdStage);
        controller.setProd(selectedProd);

        // Show the dialog and wait until the user closes it
        modifyProdStage.showAndWait();

        return controller.SaveClicked();
    } catch (IOException e) {
        e.printStackTrace();
        return false;
    }
}
     
     public Stage getPrimaryStage() {
         return primaryStage;
     }
     
     


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

  
    
}
